1 - compile the code 
> make clean
> make

2 - import it in a python script
> import R_tools_fort as toolsF

3 - use it as a normal function
> var = toolsF.rho_eos(T,S,z_r,z_w,rho0)
